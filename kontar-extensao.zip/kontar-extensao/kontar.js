// Roda no site do Kontar: avisa que a extensão está instalada e leva os pedidos da página até o background.
document.documentElement.setAttribute('data-kontar-ext', chrome.runtime.getManifest().version);
window.addEventListener('message', ev => {
  if (ev.source !== window || !ev.data || ev.data.kontar !== 'atualizar') return;
  chrome.runtime.sendMessage({ t: 'atualizar' });
});
chrome.runtime.onMessage.addListener(m => { if (m && m.kontarExt) window.postMessage(m, location.origin); });
