// Kontar · Atualizar MeuPluggy. Abre meu.pluggy.ai/connections numa aba em segundo plano, clica em "Atualizar" em cada
// conexão (uma depois da outra), fecha a aba e conta o resultado pro Kontar. Se não houver login, mostra a aba pra pessoa entrar.
const URL_CX = 'https://meu.pluggy.ai/connections';
let rodando = false;

const conta = (tabId, m) => chrome.tabs.sendMessage(tabId, Object.assign({ kontarExt: true }, m)).catch(() => {});
const carregou = tabId => new Promise(res => {
  const f = (id, info) => { if (id === tabId && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(f); res(); } };
  chrome.tabs.onUpdated.addListener(f);
  setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); res(); }, 30000);
});

// roda DENTRO da página do MeuPluggy (mundo da página, pra usar o roteador do site)
async function atualizaTudo() {
  const S = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 40 && !(window.next && window.next.router && document.querySelector('a[href*="/connections/"]')); i++) await S(250);
  const R = window.next && window.next.router;
  const ids = [...new Set([...document.querySelectorAll('a[href*="/connections/"]')].map(a => a.getAttribute('href')))];
  if (!R || !ids.length) return { login: true, ok: [], falha: [], total: 0 };
  const ok = [], falha = [];
  for (const href of ids) {
    await R.push(href); let b = null;
    for (let i = 0; i < 60 && !b; i++) { await S(250); b = [...document.querySelectorAll('button')].find(x => /^(Atualizar|Update)$/i.test(x.textContent.trim()) && !x.disabled); }
    await S(600); const nome = (document.title || '').split(' — ')[0];
    if (!b) { falha.push(nome); continue; }
    const n0 = document.querySelectorAll('iframe').length; b.click(); const t0 = Date.now(); let abriu = false;
    while (Date.now() - t0 < 60000) { await S(300); const n = document.querySelectorAll('iframe').length; if (n > n0) abriu = true; else if (abriu) break; }
    (abriu ? ok : falha).push(nome); await S(500);
  }
  return { login: false, ok, falha, total: ids.length };
}

chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || m.t !== 'atualizar' || !sender.tab) return;
  const kTab = sender.tab.id;
  if (rodando) { conta(kTab, { estado: 'ocupado' }); return; }
  rodando = true;
  (async () => {
    let tab = null;
    try {
      conta(kTab, { estado: 'comecou' });
      tab = await chrome.tabs.create({ url: URL_CX, active: false });
      await carregou(tab.id);
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: atualizaTudo });
      const res = (r && r.result) || { ok: [], falha: [], total: 0 };
      if (res.login) { await chrome.tabs.update(tab.id, { active: true }); tab = null; conta(kTab, { estado: 'login' }); return; }
      conta(kTab, Object.assign({ estado: 'fim' }, res));
    } catch (e) {
      conta(kTab, { estado: 'erro', msg: String(e && e.message || e).slice(0, 200) });
    } finally {
      if (tab) chrome.tabs.remove(tab.id).catch(() => {});
      rodando = false;
    }
  })();
});
